%% EXPERIMENT 07: BLOOD PRESSURE REGULATION MODEL
% Course: EC4414 / 19BM414 | CO4
% Simplified feedback model for teaching; not a physiological prediction.
clear; close all; clc;
dt=0.01; t=0:dt:60; setPoint=90; tau=7; feedbackGain=0.8;
disturbance=zeros(size(t));
disturbance(t>=10 & t<22)=18; % temporary disturbance
pressure=zeros(size(t)); pressure(1)=setPoint;
for k=2:numel(t)
    feedbackCorrection=feedbackGain*(setPoint-pressure(k-1));
    target=setPoint+disturbance(k)+feedbackCorrection;
    pressure(k)=pressure(k-1)+(dt/tau)*(target-pressure(k-1));
end
figure('Color','w','Name','Blood pressure regulation');
plot(t,pressure,'LineWidth',1.4); hold on;
plot(t,setPoint*ones(size(t)),'--');
plot(t,setPoint+disturbance,':');
grid on; xlabel('Time (s)'); ylabel('Pressure (arbitrary units)');
title('First-order feedback response to a temporary disturbance');
legend('Model pressure','Set point','Disturbed reference','Location','best');
outDir=fullfile(fileparts(mfilename('fullpath')),'..','results');
if ~exist(outDir,'dir'), mkdir(outDir); end
saveas(gcf,fullfile(outDir,'blood_pressure_response.png'));
