# Experiment 07: Blood Pressure Regulation Models

**Course:** EC4414 / 19BM414 – MATLAB for Biomedical Engineers  
**Course Outcome:** CO4

## 1. Aim
To demonstrate a first-order feedback response to a temporary disturbance in a blood-pressure-like variable.

## 2. Software requirements
Base MATLAB.

## 3. Theory
A first-order discrete-time model is used to illustrate feedback toward a set point. The disturbance and model coefficients are hypothetical and are not a patient-specific or clinically validated baroreflex model.

## 4. Algorithm
1. Define the set point, time constant and feedback gain.
2. Apply a temporary disturbance over a selected interval.
3. Update the model state at each time step using feedback.
4. Plot response, set point and disturbed reference.

## 5. Files in this folder
- `code/Experiment_XX.m` – MATLAB implementation.
- `figures/Experiment_XX_reference.png` – explanatory reference figure.
- `results/` – generated outputs; the MATLAB script saves its result here.

## 6. Procedure
1. Open MATLAB.
2. Set the Current Folder to this experiment's `code` folder.
3. Run the script `Experiment_XX.m`.
4. Inspect the figure and any command-window output.
5. Record the observations in your laboratory record.

## 7. Expected observations
- Observe the response during and after the disturbance.
- Describe how the feedback gain changes the response.
- Discuss the role of the time constant.

## 8. Result
The experiment is completed when the script runs, the output figure is generated, and the observations are recorded. Enter actual observations from your MATLAB run; do not copy illustrative values as measured results.

## 9. Review questions
1. What is negative feedback?
2. How would increasing the time constant change the response?
3. Why is this model not sufficient to predict an individual's blood pressure?

## 10. Limitations and responsible use
The supplied program is a teaching demonstration. Synthetic signals/images/data are not clinical evidence. Do not use these scripts for diagnosis, treatment decisions, or claims of clinical accuracy. For real patient data, obtain institutional approval, use de-identified data, and follow applicable data-governance requirements.
