%% EXPERIMENT 09: SIMULINK MODEL FOR PHYSIOLOGICAL SYSTEMS
% Course: EC4414 / 19BM414 | CO4
% Part A runs a base-MATLAB simulation. Part B gives Simulink construction steps.
clear; close all; clc;
tau=5; dt=0.01; t=0:dt:30; inputSignal=ones(size(t)); response=zeros(size(t));
for k=2:numel(t)
    response(k)=response(k-1)+dt*(inputSignal(k)-response(k-1))/tau;
end
figure('Color','w','Name','First-order physiological system');
plot(t,inputSignal,'--','LineWidth',1.2); hold on;
plot(t,response,'LineWidth',1.5); grid on;
xlabel('Time (s)'); ylabel('Normalized amplitude');
title('First-order physiological system response');
legend('Step input','System output','Location','best');
outDir=fullfile(fileparts(mfilename('fullpath')),'..','results');
if ~exist(outDir,'dir'), mkdir(outDir); end
saveas(gcf,fullfile(outDir,'physiological_system_result.png'));

% Simulink construction guide:
% 1. Open Simulink and create a Blank Model.
% 2. Add Step, Sum, Gain, Integrator, and Scope blocks.
% 3. Connect Step -> Sum -> Gain -> Integrator -> Scope.
% 4. Connect Integrator output to the negative input of Sum (feedback).
% 5. Set Gain to 1/tau (0.2), Sum signs to '+-', and Stop Time to 30.
% 6. Run the model and compare Scope output with the MATLAB plot above.
