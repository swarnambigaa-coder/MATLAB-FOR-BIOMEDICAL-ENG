# Experiment 09: Simulink Model for Physiological Systems

**Course:** EC4414 / 19BM414 – MATLAB for Biomedical Engineers  
**Course Outcome:** CO4

## 1. Aim
To compare a first-order physiological-system response in MATLAB with a block-based Simulink implementation.

## 2. Software requirements
Base MATLAB for the script; Simulink for the block-diagram portion.

## 3. Theory
A first-order system can be represented by dy/dt = (u-y)/tau. A step input is applied and the output is computed numerically. The README describes an equivalent feedback structure using Step, Sum, Gain, Integrator and Scope blocks.

## 4. Algorithm
1. Run the MATLAB script and observe the step response.
2. Open Simulink and create a blank model.
3. Add Step, Sum, Gain, Integrator and Scope blocks.
4. Connect the forward path and negative feedback path as described.
5. Set gain to 1/tau and compare the Scope output with the MATLAB result.

## 5. Files in this folder
- `code/Experiment_XX.m` – MATLAB implementation.
- `figures/Experiment_XX_reference.png` – explanatory reference figure.
- `results/` – generated outputs; the MATLAB script saves its result here.

## 6. Procedure
1. Open MATLAB.
2. Set the Current Folder to this experiment's `code` folder.
3. Run the script `Experiment_XX.m`.
4. Inspect the figure and any command-window output.
5. Record the observations in your laboratory record.

## 7. Expected observations
- Record the approximate time taken to approach steady state.
- Compare the MATLAB plot and Simulink Scope output.
- Explain the role of each block.

## 8. Result
The experiment is completed when the script runs, the output figure is generated, and the observations are recorded. Enter actual observations from your MATLAB run; do not copy illustrative values as measured results.

## 9. Review questions
1. What does the time constant represent?
2. Why is negative feedback used in this block diagram?
3. What differences can arise from solver and step-size settings?

## 10. Limitations and responsible use
The supplied program is a teaching demonstration. Synthetic signals/images/data are not clinical evidence. Do not use these scripts for diagnosis, treatment decisions, or claims of clinical accuracy. For real patient data, obtain institutional approval, use de-identified data, and follow applicable data-governance requirements.
