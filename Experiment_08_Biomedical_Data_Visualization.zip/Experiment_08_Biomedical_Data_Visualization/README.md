# Experiment 08: Biomedical Data Visualization

**Course:** EC4414 / 19BM414 – MATLAB for Biomedical Engineers  
**Course Outcome:** CO5

## 1. Aim
To create common visualizations for synthetic biomedical measurements.

## 2. Software requirements
Base MATLAB.

## 3. Theory
Time-series plots show changes across samples; scatter plots reveal relationships between variables; histograms show distributions. The generated data are synthetic and intended for visualization practice.

## 4. Algorithm
1. Generate reproducible synthetic heart rate, SpO2, temperature and systolic pressure values.
2. Plot time-series trends.
3. Create a scatter plot for two variables.
4. Plot a histogram and export the example dataset as CSV.

## 5. Files in this folder
- `code/Experiment_XX.m` – MATLAB implementation.
- `figures/Experiment_XX_reference.png` – explanatory reference figure.
- `results/` – generated outputs; the MATLAB script saves its result here.

## 6. Procedure
1. Open MATLAB.
2. Set the Current Folder to this experiment's `code` folder.
3. Run the script `Experiment_XX.m`.
4. Inspect the figure and any command-window output.
5. Record the observations in your laboratory record.

## 7. Expected observations
- Describe the trend in heart rate and SpO2.
- Observe the distribution of temperature.
- Open the exported CSV and identify its columns.

## 8. Result
The experiment is completed when the script runs, the output figure is generated, and the observations are recorded. Enter actual observations from your MATLAB run; do not copy illustrative values as measured results.

## 9. Review questions
1. When is a scatter plot more informative than a time-series plot?
2. What does a histogram reveal?
3. How can missing values and outliers affect visualization?

## 10. Limitations and responsible use
The supplied program is a teaching demonstration. Synthetic signals/images/data are not clinical evidence. Do not use these scripts for diagnosis, treatment decisions, or claims of clinical accuracy. For real patient data, obtain institutional approval, use de-identified data, and follow applicable data-governance requirements.
