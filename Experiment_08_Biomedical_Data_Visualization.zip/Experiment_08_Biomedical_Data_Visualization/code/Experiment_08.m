%% EXPERIMENT 08: BIOMEDICAL DATA VISUALIZATION
% Course: EC4414 / 19BM414 | CO5
% Synthetic measurements for plotting practice.
clear; close all; clc; rng(18);
n=120; sample=(1:n)';
heartRate=72+7*sin(2*pi*sample/35)+4*randn(n,1);
spo2=97-0.035*(heartRate-72)+0.7*randn(n,1);
temperature=36.8+0.25*randn(n,1);
systolicBP=118+0.25*(heartRate-72)+7*randn(n,1);
figure('Color','w','Name','Biomedical data visualization');
subplot(2,2,1); plot(sample,heartRate); grid on;
xlabel('Sample'); ylabel('Heart rate (bpm)'); title('Heart-rate trend');
subplot(2,2,2); plot(sample,spo2); grid on;
xlabel('Sample'); ylabel('SpO_2 (%)'); title('Oxygen saturation trend');
subplot(2,2,3); scatter(heartRate,spo2,22,'filled'); grid on;
xlabel('Heart rate (bpm)'); ylabel('SpO_2 (%)'); title('Heart rate vs SpO_2');
subplot(2,2,4); histogram(temperature); grid on;
xlabel('Temperature (°C)'); ylabel('Frequency'); title('Temperature distribution');
outDir=fullfile(fileparts(mfilename('fullpath')),'..','results');
if ~exist(outDir,'dir'), mkdir(outDir); end
saveas(gcf,fullfile(outDir,'biomedical_visualization_result.png'));
% Save synthetic example data for optional student exploration.
dataTable=table(sample,heartRate,spo2,temperature,systolicBP);
writetable(dataTable,fullfile(outDir,'synthetic_biomedical_data.csv'));
