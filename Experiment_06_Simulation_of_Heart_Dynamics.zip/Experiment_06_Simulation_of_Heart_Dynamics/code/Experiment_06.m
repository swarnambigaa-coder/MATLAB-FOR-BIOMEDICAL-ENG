%% EXPERIMENT 06: SIMULATION OF HEART DYNAMICS
% Course: EC4414 / 19BM414 | CO4
% Simplified educational model; not a validated cardiovascular simulator.
clear; close all; clc;
fs=500; duration=8; t=(0:1/fs:duration)';
heartRate=75; cycle=60/heartRate; phase=mod(t,cycle)/cycle;
% Stylized periodic ventricular pressure and volume waveforms.
activation=exp(-((phase-0.32)/0.13).^2);
pressure=8 + 115*activation + 5*sin(2*pi*phase);
ejection=1./(1+exp(-(phase-0.30)/0.035));
filling=1./(1+exp(-(phase-0.78)/0.045));
volume=120 - 55*ejection + 55*filling;
figure('Color','w','Name','Simplified heart dynamics');
subplot(3,1,1); plot(t,pressure); grid on; ylabel('Pressure (a.u.)');
title('Simplified ventricular pressure');
subplot(3,1,2); plot(t,volume); grid on; ylabel('Volume (a.u.)');
title('Simplified ventricular volume');
subplot(3,1,3); plot(volume,pressure); grid on;
xlabel('Volume (a.u.)'); ylabel('Pressure (a.u.)'); title('Pressure-volume loop (stylized)');
outDir=fullfile(fileparts(mfilename('fullpath')),'..','results');
if ~exist(outDir,'dir'), mkdir(outDir); end
saveas(gcf,fullfile(outDir,'heart_dynamics_result.png'));
