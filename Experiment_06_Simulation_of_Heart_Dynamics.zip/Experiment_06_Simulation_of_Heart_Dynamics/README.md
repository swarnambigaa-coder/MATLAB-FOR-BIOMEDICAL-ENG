# Experiment 06: Simulation of Heart Dynamics

**Course:** EC4414 / 19BM414 – MATLAB for Biomedical Engineers  
**Course Outcome:** CO4

## 1. Aim
To simulate stylized periodic pressure and volume patterns across repeated cardiac cycles.

## 2. Software requirements
Base MATLAB.

## 3. Theory
A simplified periodic waveform can illustrate how pressure and ventricular volume change over a cardiac cycle. The model is phenomenological and does not solve a validated cardiovascular physiology model.

## 4. Algorithm
1. Set sampling frequency, duration and nominal heart rate.
2. Calculate normalized phase within each cardiac cycle.
3. Generate stylized activation, pressure and volume curves.
4. Plot pressure, volume and a pressure-volume representation.

## 5. Files in this folder
- `code/Experiment_XX.m` – MATLAB implementation.
- `figures/Experiment_XX_reference.png` – explanatory reference figure.
- `results/` – generated outputs; the MATLAB script saves its result here.

## 6. Procedure
1. Open MATLAB.
2. Set the Current Folder to this experiment's `code` folder.
3. Run the script `Experiment_XX.m`.
4. Inspect the figure and any command-window output.
5. Record the observations in your laboratory record.

## 7. Expected observations
- Identify the repeated cardiac cycles.
- Describe the relative timing of pressure and volume changes.
- Observe the stylized pressure-volume loop.

## 8. Result
The experiment is completed when the script runs, the output figure is generated, and the observations are recorded. Enter actual observations from your MATLAB run; do not copy illustrative values as measured results.

## 9. Review questions
1. How does changing heart rate affect cycle duration?
2. What physiological processes are omitted from this simplified model?
3. Why should model parameters not be interpreted as patient measurements?

## 10. Limitations and responsible use
The supplied program is a teaching demonstration. Synthetic signals/images/data are not clinical evidence. Do not use these scripts for diagnosis, treatment decisions, or claims of clinical accuracy. For real patient data, obtain institutional approval, use de-identified data, and follow applicable data-governance requirements.
