# Experiment 05: Disease Classification Using Biomedical Datasets

**Course:** EC4414 / 19BM414 – MATLAB for Biomedical Engineers  
**Course Outcome:** CO3

## 1. Aim
To implement a simple binary classification workflow using two synthetic biomedical features.

## 2. Software requirements
Base MATLAB.

## 3. Theory
The script standardizes features using training-set statistics and fits logistic regression with gradient descent. A held-out test subset is used for a basic confusion matrix and accuracy calculation. Synthetic accuracy is only a code demonstration.

## 4. Algorithm
1. Generate two labelled synthetic classes.
2. Randomly split the dataset into training and test subsets.
3. Standardize features using training-set mean and standard deviation only.
4. Train logistic regression using gradient descent.
5. Predict test labels and calculate confusion-matrix counts and accuracy.

## 5. Files in this folder
- `code/Experiment_XX.m` – MATLAB implementation.
- `figures/Experiment_XX_reference.png` – explanatory reference figure.
- `results/` – generated outputs; the MATLAB script saves its result here.

## 6. Procedure
1. Open MATLAB.
2. Set the Current Folder to this experiment's `code` folder.
3. Run the script `Experiment_XX.m`.
4. Inspect the figure and any command-window output.
5. Record the observations in your laboratory record.

## 7. Expected observations
- Inspect the feature scatter plot.
- Record TP, TN, FP and FN.
- Calculate accuracy from the confusion matrix and discuss its limitations.

## 8. Result
The experiment is completed when the script runs, the output figure is generated, and the observations are recorded. Enter actual observations from your MATLAB run; do not copy illustrative values as measured results.

## 9. Review questions
1. Why should standardization use training data only?
2. What do sensitivity and specificity measure?
3. Why is accuracy insufficient for imbalanced datasets?

## 10. Limitations and responsible use
The supplied program is a teaching demonstration. Synthetic signals/images/data are not clinical evidence. Do not use these scripts for diagnosis, treatment decisions, or claims of clinical accuracy. For real patient data, obtain institutional approval, use de-identified data, and follow applicable data-governance requirements.
