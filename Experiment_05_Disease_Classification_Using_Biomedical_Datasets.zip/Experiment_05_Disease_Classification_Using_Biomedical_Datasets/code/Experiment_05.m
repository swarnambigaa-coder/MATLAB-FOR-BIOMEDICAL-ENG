%% EXPERIMENT 05: DISEASE CLASSIFICATION USING BIOMEDICAL DATA
% Course: EC4414 / 19BM414 | CO3
% Synthetic data + logistic regression implemented with base MATLAB.
% Not a validated diagnostic model. Do not interpret as clinical performance.
clear; close all; clc; rng(15);
nPerClass=120;
class0=[randn(nPerClass,1)*0.8+1.2, randn(nPerClass,1)*0.7+1.4];
class1=[randn(nPerClass,1)*0.8+2.6, randn(nPerClass,1)*0.8+2.8];
X=[class0;class1]; y=[zeros(nPerClass,1);ones(nPerClass,1)];
perm=randperm(size(X,1)); X=X(perm,:); y=y(perm);
nTrain=round(0.70*numel(y));
Xtrain=X(1:nTrain,:); ytrain=y(1:nTrain);
Xtest=X(nTrain+1:end,:); ytest=y(nTrain+1:end);

% Standardize using training-set statistics only (avoid test leakage).
mu=mean(Xtrain,1); sigma=std(Xtrain,0,1); sigma(sigma==0)=1;
A=(Xtrain-mu)./sigma; B=(Xtest-mu)./sigma;
A=[ones(size(A,1),1),A]; B=[ones(size(B,1),1),B];
theta=zeros(size(A,2),1); alpha=0.1; iterations=1500;
for k=1:iterations
    z=max(min(A*theta,30),-30);
    probability=1./(1+exp(-z));
    gradient=(A'*(probability-ytrain))/numel(ytrain);
    theta=theta-alpha*gradient;
end
testProbability=1./(1+exp(-max(min(B*theta,30),-30)));
prediction=testProbability>=0.5;
accuracy=mean(prediction==ytest);
TP=sum(prediction==1 & ytest==1); TN=sum(prediction==0 & ytest==0);
FP=sum(prediction==1 & ytest==0); FN=sum(prediction==0 & ytest==1);
fprintf('Synthetic test accuracy: %.3f\\n',accuracy);
fprintf('TP=%d, TN=%d, FP=%d, FN=%d\\n',TP,TN,FP,FN);

figure('Color','w','Name','Biomedical classification');
subplot(1,2,1);
scatter(class0(:,1),class0(:,2),18,'o'); hold on;
scatter(class1(:,1),class1(:,2),18,'+'); grid on;
xlabel('Feature 1'); ylabel('Feature 2'); title('Synthetic feature distribution');
legend('Class 0','Class 1','Location','best');
subplot(1,2,2); imagesc([TN FP; FN TP]); axis image; colorbar;
set(gca,'XTick',1:2,'XTickLabel',{'Pred 0','Pred 1'}, ...
    'YTick',1:2,'YTickLabel',{'Actual 0','Actual 1'});
title(sprintf('Confusion matrix (accuracy %.1f%%)',100*accuracy));
outDir=fullfile(fileparts(mfilename('fullpath')),'..','results');
if ~exist(outDir,'dir'), mkdir(outDir); end
saveas(gcf,fullfile(outDir,'classification_result.png'));
