# Experiment 04: DICOM Image Analysis

**Course:** EC4414 / 19BM414 – MATLAB for Biomedical Engineers  
**Course Outcome:** CO2

## 1. Aim
To load and display a DICOM image and inspect basic image metadata.

## 2. Software requirements
MATLAB installation with `dicominfo` and `dicomread` support; availability depends on release and installed products.

## 3. Theory
DICOM is a standard for storing and exchanging medical imaging data. The DICOM header contains metadata such as rows, columns, modality and acquisition details. Image display should account for modality-specific rescaling and windowing when appropriate.

## 4. Algorithm
1. Run the script and select a DICOM file when available.
2. Read metadata using dicominfo.
3. Read pixel data using dicomread.
4. Display the image with a grayscale map and color bar.
5. If no file is selected, inspect the synthetic fallback image.

## 5. Files in this folder
- `code/Experiment_XX.m` – MATLAB implementation.
- `figures/Experiment_XX_reference.png` – explanatory reference figure.
- `results/` – generated outputs; the MATLAB script saves its result here.

## 6. Procedure
1. Open MATLAB.
2. Set the Current Folder to this experiment's `code` folder.
3. Run the script `Experiment_XX.m`.
4. Inspect the figure and any command-window output.
5. Record the observations in your laboratory record.

## 7. Expected observations
- Record image dimensions when a DICOM file is loaded.
- Identify selected metadata fields in the command window.
- Compare the display of the DICOM image with the fallback.

## 8. Result
The experiment is completed when the script runs, the output figure is generated, and the observations are recorded. Enter actual observations from your MATLAB run; do not copy illustrative values as measured results.

## 9. Review questions
1. What is the role of DICOM metadata?
2. Why may raw pixel values require rescaling or windowing?
3. What privacy precautions apply to DICOM headers?

## 10. Limitations and responsible use
The supplied program is a teaching demonstration. Synthetic signals/images/data are not clinical evidence. Do not use these scripts for diagnosis, treatment decisions, or claims of clinical accuracy. For real patient data, obtain institutional approval, use de-identified data, and follow applicable data-governance requirements.
