%% EXPERIMENT 04: DICOM IMAGE ANALYSIS
% Course: EC4414 / 19BM414 | CO2
% Requires MATLAB DICOM functions (availability depends on MATLAB release/toolboxes).
clear; close all; clc;
[fileName,folderName]=uigetfile({'*.dcm;*.ima','DICOM files (*.dcm, *.ima)';'*.*','All files'}, ...
    'Select a DICOM image');
if isequal(fileName,0)
    % Demonstration fallback so the workflow can still be observed.
    [X,Y]=meshgrid(linspace(-1,1,256));
    imageData=0.8*exp(-((X/0.72).^2+(Y/0.85).^2))+0.08*rand(256);
    dicomMetadata=[];
    fprintf('No file selected. Showing a synthetic demonstration image.\\n');
else
    fullName=fullfile(folderName,fileName);
    dicomMetadata=dicominfo(fullName);
    imageData=dicomread(dicomMetadata);
    fprintf('Loaded: %s\\n',fullName);
    fprintf('Rows: %d | Columns: %d\\n',dicomMetadata.Rows,dicomMetadata.Columns);
    disp(dicomMetadata);
end
figure('Color','w','Name','DICOM image analysis');
imagesc(imageData); axis image; colormap gray; colorbar;
title('DICOM / demonstration image'); xlabel('Column'); ylabel('Row');
outDir=fullfile(fileparts(mfilename('fullpath')),'..','results');
if ~exist(outDir,'dir'), mkdir(outDir); end
saveas(gcf,fullfile(outDir,'dicom_display_result.png'));
