%% EXPERIMENT 03: TUMOR SEGMENTATION - THRESHOLDING AND REGION GROWING
% Course: EC4414 / 19BM414 | CO2
% Synthetic image only. Not for diagnosis or clinical decision-making.
clear; close all; clc; rng(13);
n=220; [X,Y]=meshgrid(1:n,1:n);
brainMask=((X-110).^2/88^2+(Y-112).^2/96^2)<=1;
imageData=0.12+0.04*rand(n);
imageData(~brainMask)=0.02;
% Simulated bright lesion within the synthetic brain-shaped region.
lesion=((X-142).^2/23^2+(Y-94).^2/18^2)<=1;
imageData(lesion)=0.78+0.06*rand(nnz(lesion),1);
imageData=max(0,min(1,imageData));

% Method 1: intensity thresholding.
threshold=0.60;
thresholdMask=(imageData>=threshold) & brainMask;

% Method 2: 4-connected seed-based region growing.
seedX=142; seedY=94; tolerance=0.16;
seedIntensity=imageData(seedY,seedX);
eligible=abs(imageData-seedIntensity)<=tolerance & brainMask;
regionMask=false(n,n);
queue=zeros(n*n,2); head=1; tail=1;
queue(tail,:)=[seedX seedY]; regionMask(seedY,seedX)=true;
while head<=tail
    current=queue(head,:); head=head+1;
    neighbors=[current+[1 0]; current+[-1 0]; current+[0 1]; current+[0 -1]];
    for q=1:4
        xx=neighbors(q,1); yy=neighbors(q,2);
        if xx>=1 && xx<=n && yy>=1 && yy<=n && ...
                eligible(yy,xx) && ~regionMask(yy,xx)
            tail=tail+1; queue(tail,:)=neighbors(q,:);
            regionMask(yy,xx)=true;
        end
    end
end
fprintf('Threshold mask pixels: %d\\n',nnz(thresholdMask));
fprintf('Region-growing pixels: %d\\n',nnz(regionMask));

figure('Color','w','Name','Tumor segmentation demonstration');
subplot(1,3,1); imagesc(imageData); axis image off; colormap gray; title('Synthetic input image');
subplot(1,3,2); imagesc(thresholdMask); axis image off; title('Threshold result');
subplot(1,3,3); imagesc(regionMask); axis image off; title('Region-growing result');
outDir=fullfile(fileparts(mfilename('fullpath')),'..','results');
if ~exist(outDir,'dir'), mkdir(outDir); end
saveas(gcf,fullfile(outDir,'segmentation_comparison.png'));
