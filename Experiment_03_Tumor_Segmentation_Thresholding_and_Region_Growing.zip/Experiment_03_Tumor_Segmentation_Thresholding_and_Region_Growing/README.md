# Experiment 03: Tumor Segmentation Using Thresholding and Region Growing

**Course:** EC4414 / 19BM414 – MATLAB for Biomedical Engineers  
**Course Outcome:** CO2

## 1. Aim
To compare global intensity thresholding with seed-based region growing on a synthetic image.

## 2. Software requirements
Base MATLAB.

## 3. Theory
Thresholding labels pixels according to intensity. Region growing starts from a seed and adds connected neighboring pixels satisfying an intensity similarity criterion. The synthetic image is used only to demonstrate algorithm mechanics.

## 4. Algorithm
1. Create a synthetic brain-shaped background and bright simulated lesion.
2. Apply a global intensity threshold within the brain mask.
3. Select a seed point inside the simulated lesion.
4. Use 4-connected neighbors and an intensity tolerance to grow the region.
5. Compare the resulting masks visually and by pixel count.

## 5. Files in this folder
- `code/Experiment_XX.m` – MATLAB implementation.
- `figures/Experiment_XX_reference.png` – explanatory reference figure.
- `results/` – generated outputs; the MATLAB script saves its result here.

## 6. Procedure
1. Open MATLAB.
2. Set the Current Folder to this experiment's `code` folder.
3. Run the script `Experiment_XX.m`.
4. Inspect the figure and any command-window output.
5. Record the observations in your laboratory record.

## 7. Expected observations
- Observe the synthetic input and two segmentation masks.
- Compare the area selected by each method.
- Discuss how threshold and seed selection affect segmentation.

## 8. Result
The experiment is completed when the script runs, the output figure is generated, and the observations are recorded. Enter actual observations from your MATLAB run; do not copy illustrative values as measured results.

## 9. Review questions
1. What happens when the threshold is too low or too high?
2. How does seed placement affect region growing?
3. Why is validation against expert annotations required for medical segmentation?

## 10. Limitations and responsible use
The supplied program is a teaching demonstration. Synthetic signals/images/data are not clinical evidence. Do not use these scripts for diagnosis, treatment decisions, or claims of clinical accuracy. For real patient data, obtain institutional approval, use de-identified data, and follow applicable data-governance requirements.
